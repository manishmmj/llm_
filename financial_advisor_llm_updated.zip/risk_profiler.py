def predict_risk():
    # Dummy logic
    return "Moderate"